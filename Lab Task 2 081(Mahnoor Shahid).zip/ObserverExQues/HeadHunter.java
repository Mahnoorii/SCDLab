/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ObserverExQues;

import java.util.ArrayList;
import java.util.List;

public class HeadHunter implements Subject {
    private List<Observer> developers;
    private List<String> jobList;

    public HeadHunter() {
        this.developers = new ArrayList<>();
        this.jobList = new ArrayList<>();
    }

    @Override
    public void registerObserver(Observer developer) {
        developers.add(developer);
    }

    @Override
    public void removeObserver(Observer developer) {
        developers.remove(developer);
    }

    @Override
    public void notifyObservers() {
        for (Observer developer : developers) {
            developer.update(jobList.get(jobList.size() - 1)); // Notifying about the latest job
        }
    }

    // Adds a new job and notifies all developers
    public void addJob(String job) {
        this.jobList.add(job);
        notifyObservers();
    }
}
