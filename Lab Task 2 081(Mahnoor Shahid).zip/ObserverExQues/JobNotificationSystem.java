/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ObserverExQues;

/**
 *
 * @author Usama
 */
public class JobNotificationSystem {
    public static void main(String[] args) {
        HeadHunter headHunter = new HeadHunter();

        // Create developers (observers)
        Developer dev1 = new Developer("John Doe");
        Developer dev2 = new Developer("Jane Smith");
        Developer dev3 = new Developer("Tom Williams");

        // Developers register with the head hunter
        headHunter.registerObserver(dev1);
        headHunter.registerObserver(dev2);
        headHunter.registerObserver(dev3);

        // Head hunter posts a new job
        headHunter.addJob("Software Engineer at ABC Corp");

        // One developer decides to unsubscribe
        headHunter.removeObserver(dev2);

        // Head hunter posts another job
        headHunter.addJob("Full Stack Developer at XYZ Ltd");
    }
}
