/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mortgage;

/**
 *
 * @author Usama
 */
public class Bank {
    public boolean hasSufficientSavings(Customer customer, double amount) {
        // Simple mock check
        System.out.println("Checking bank for " + customer.getName());
        return amount <= 50000; // Assuming savings check
    }
}
