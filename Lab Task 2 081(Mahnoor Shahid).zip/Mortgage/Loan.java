/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mortgage;

/**
 *
 * @author Usama
 */
public class Loan {
    public boolean hasNoBadLoans(Customer customer) {
        // Simple mock loan check
        System.out.println("Checking loans for " + customer.getName());
        return customer.getLoanBalance() == 0; // Assuming loan balance check
    }
}
