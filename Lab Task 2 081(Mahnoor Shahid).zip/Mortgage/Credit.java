/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mortgage;

/**
 *
 * @author Usama
 */
public class Credit {
    public boolean hasGoodCredit(Customer customer) {
        // Simple mock credit check
        System.out.println("Checking credit for " + customer.getName());
        return customer.getCreditScore() > 700; // Assuming credit score check
    }
}
