/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mortgage;

/**
 *
 * @author Usama
 */
public class Mortgage {
    private Bank bank;
    private Credit credit;
    private Loan loan;

    public Mortgage() {
        bank = new Bank();
        credit = new Credit();
        loan = new Loan();
    }

    public boolean isEligible(Customer customer, double amount) {
        System.out.println("Evaluating mortgage eligibility for " + customer.getName());

        boolean eligible = bank.hasSufficientSavings(customer, amount)
                && credit.hasGoodCredit(customer)
                && loan.hasNoBadLoans(customer);

        return eligible;
    }
}
