/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mortgage;

/**
 *
 * @author Usama
 */
public class MortgageApplicationDemo {
    public static void main(String[] args) {
        Customer customer = new Customer("John Doe", 750, 0); // Good credit and no loans
        Mortgage mortgage = new Mortgage();

        double loanAmount = 40000; // Customer is applying for a loan of 40000

        if (mortgage.isEligible(customer, loanAmount)) {
            System.out.println(customer.getName() + " has been approved for the mortgage.");
        } else {
            System.out.println(customer.getName() + " has been denied for the mortgage.");
        }
    }
}
