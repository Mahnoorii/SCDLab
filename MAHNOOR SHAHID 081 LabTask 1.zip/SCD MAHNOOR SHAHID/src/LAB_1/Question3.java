/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB_1;

class Anim{
    String name;
    public void makeSound() {
        System.out.println("Dog voice");
    }
}
class Dog extends Anim{
    String breed;
    public Dog(String name, String breed) { 
        this.breed=breed;
        this.name=name;
    }


    public void makeSound() {
        super.makeSound(); 
        System.out.println(breed+" food");
        System.out.println(name + " barks."); 
    }
}

public class Question3 {
     public static void main(String[] args) {
        Dog myDog = new Dog("Buddy", "Bones");
        myDog.makeSound();   
    }
}