/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB_1;

/**
 *
 * @author stu
 */
interface Animal {
    void eat();
    void travel();
}

public class ques_1 implements Animal {
    public void eat() {
        System.out.println("Mammal eats");
    }

    public void travel() {
        System.out.println("Mammal travels");
    }

    public int noOfLegs() {
        return 0; 
    }

    public static void main(String args[]) {
        ques_1 m = new ques_1(); 
        m.eat();
        m.travel();
    }
}
