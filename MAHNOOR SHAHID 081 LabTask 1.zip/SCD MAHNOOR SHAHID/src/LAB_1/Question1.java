/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB_1;

public class Question1 {
    int value;
    public Question1(int value) {
        this.value = value;
    }
      public int getValue() {
        return this.value; 
    }
    public static void main(String args[]){
        Question1 obj=new Question1(33);
        System.out.println("Set Value is "+obj.getValue());
        
    } 
}