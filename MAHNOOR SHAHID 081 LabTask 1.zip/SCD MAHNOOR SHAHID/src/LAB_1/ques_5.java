/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB_1;

// Assuming we have an Animal class like this
class Ani {
    public String walk() {
        return "This animal can walk";
    }

    public String hasLegs() {
        return "This animal has legs";
    }
}

// Creating the Fish class which inherits from Ani
class Fish extends Ani {

    @Override
    public String walk() {
        return "Fish cannot walk";
    }

    @Override
    public String hasLegs() {
        return "Fish has no legs";
    }
}

// Example usage
public class ques_5 {
    public static void main(String[] args) {
        Fish fish = new Fish();
        System.out.println(fish.walk());      // Output: Fish can't walk.
        System.out.println(fish.hasLegs());   // Output: Fish don't have legs.
    }
}
