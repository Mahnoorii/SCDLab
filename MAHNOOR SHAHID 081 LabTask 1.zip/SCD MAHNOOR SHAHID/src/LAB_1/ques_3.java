/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB_1;
interface In1
{
final int a = 10;
default void display()
{
System.out.println("hello");
}
}
// A class that implements the interface.
class TestClass implements In1
{
    public void display()
{
System.out.println("it is changed implemenatation");
}
// Driver Code
public static void main (String[] args)
{
TestClass t = new TestClass();
t.display();
}
}