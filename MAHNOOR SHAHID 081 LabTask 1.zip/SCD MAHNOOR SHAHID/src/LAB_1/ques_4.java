/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB_1;
interface ok
{
final int a = 10;
static void display()
{
System.out.println("hello");
}
}
// A class that implements the interface.
class ques4 implements ok
{
// Driver Code
public static void main (String[] args)
{
ok.display();
}
}