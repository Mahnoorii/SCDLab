/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LAB_1;

interface Test {
    int square(int number); 
}

class Arithmetic implements Test {
  
    @Override
    public int square(int number) {
        return number * number; 
    }
}
public class Question5 {
      public static void main(String[] args) {
        Arithmetic arithmetic = new Arithmetic(); 
        int number = 9; 
        int result = arithmetic.square(number); 
        System.out.println("The square of " + number + " is: " + result); 
    }
}